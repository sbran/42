/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sbran <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/05/03 16:53:16 by sbran             #+#    #+#             */
/*   Updated: 2014/05/03 20:52:28 by sbran            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <term.h>
#include <curses.h>
#include <termios.h>
#include <unistd.h>
#include <stdlib.h>
#include "ft_select.h"

t_dlist			*key_check2(t_dlist *tmp, char *buffer)
{
	if (buffer[0] == 27)
	{
		tmp->cursor = 0;
		if (buffer[1] == 91 && buffer[2] == 'A')
			tmp = tmp->prev;
		if (buffer[1] == 91 && buffer[2] == 'B')
			tmp = tmp->next;
		if (buffer[1] == 91 && buffer[2] == 'C')
			tmp = tmp->next;
		if (buffer[1] == 91 && buffer[2] == 'D')
			tmp = tmp->prev;
		tmp->cursor = 1;
	}
	if (buffer[0] == ' ')
	{
		if (tmp->select == 1)
			tmp->select = 0;
		else
			tmp->select = 1;
		tmp->cursor = 0;
		tmp = tmp->next;
		tmp->cursor = 1;
	}
	return (tmp);
}

void			ft_change2(t_dlist *tmp)
{
	if (tmp->cursor == 1)
		ft_putstr(tgetstr("us", NULL));
	if (tmp->select == 1)
		ft_putstr(tgetstr("mr", NULL));
	ft_putendl(tmp->arg);
	ft_putstr(tgetstr("me", NULL));
	ft_putstr(tgetstr("vi", NULL));
}

void			ft_change(t_dlist *lst)
{
	t_dlist		*tmp;

	ft_putstr(tgetstr("cl", NULL));
	tmp = lst;
	ft_change2(tmp);
	tmp = tmp->next;
	while (tmp != lst)
	{
		ft_change2(tmp);
		tmp = tmp->next;
	}
}

int				key_check(t_dlist *lst, struct termios *term)
{
	t_dlist	*tmp;
	char	buffer[4];

	tmp = lst;
	while (1)
	{
		ft_change(lst);
		buffer[2] = 0;
		read(0, buffer, 4);
		tmp = key_check2(tmp, buffer);
		if ((buffer[0] == 'q' || buffer[0] == 10)
					|| (buffer[0] == 27 && buffer[2] == 0))
		{
			ft_putstr(tgetstr("cl", NULL));
			ft_putstr(tgetstr("me", NULL));
			if (buffer[0] == 10)
				print_lst(lst);
			restore_shell(term);
			exit (0);
		}
	}
	return (0);
}

int				main(int ac, char **av)
{
	t_dlist			*lst;
	struct termios	term;
	char			*name_term;

	if (ac < 2)
		return (-1);
	ft_putendl("test");
	lst = init_lst(&lst, &av[1]);
	ft_putendl("test2");
	if ((name_term = getenv("TERM")) == NULL)
		return (-1);
	if (tgetent(NULL, name_term) == ERR)
		return (-1);
	if (tcgetattr(0, &term) == -1)
		return (-1);
	term.c_lflag &= ~(ICANON | ECHO);
	term.c_cc[VMIN] = 1;
	term.c_cc[VTIME] = 0;
	tcsetattr(0, TCSADRAIN, &term);
	ft_putendl("test3");
	key_check(lst, &term);
	return (0);
}
