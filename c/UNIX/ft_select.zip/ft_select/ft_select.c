/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_select.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sbran <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/04/30 18:23:29 by sbran             #+#    #+#             */
/*   Updated: 2014/05/03 20:01:37 by sbran            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <term.h>
#include <curses.h>
#include <termios.h>
#include <stdlib.h>
#include <unistd.h>
#include "ft_select.h"

int			restore_shell(struct termios *term)
{
	if (tcgetattr(0, term) == -1)
		return (-1);
	term->c_lflag = (ICANON | ECHO);
	if (tcsetattr(0, 0, term) == -1)
		return (-1);
	ft_putstr(tgetstr("ve", NULL));
	return (0);
}

void		print_lst(t_dlist *lst)
{
	t_dlist		*tmp;

	tmp = lst;
	if (tmp != NULL)
	{
		if (tmp->select == 1)
		{
			ft_putstr(tmp->arg);
			ft_putstr(" ");
		}
		tmp = tmp->next;
		while (tmp != lst)
		{
			if (tmp->select == 1)
			{
				ft_putstr(tmp->arg);
				ft_putstr(" ");
			}
			tmp = tmp->next;
		}
		ft_putstr(tgetstr("le", NULL));
	}
	ft_putchar('\n');
}

t_dlist		*create_lst(char *arg)
{
	t_dlist	*first;

	first = (t_dlist *)malloc(sizeof(t_dlist) * 1);
	if (!first)
		return (0);
	first->arg = ft_strdup(arg);
	first->select = 0;
	first->cursor = 1;
	first->prev = first;
	first->next = first;
	return (first);
}

t_dlist		*add_arg_lst(t_dlist *lst, char *arg)
{
	t_dlist	*elem;

	elem = (t_dlist *)malloc(sizeof(t_dlist));
	ft_putendl("test ARG");
	if (!elem)
		return (NULL);
	elem->arg = ft_strdup(arg);
	elem->select = 0;
	elem->cursor = 0;
	if (lst == NULL)
	{
		elem->next = elem;
		elem->prev = elem;
		lst = elem;
	}
	else
	{
		elem->prev = lst->prev;
		lst->prev->next = elem;
		elem->next = lst;
		lst->prev = elem;
	}
	lst->cursor = 1;
	return (lst);
}

t_dlist		*init_lst(t_dlist **lst, char **av)
{
	int		i;

	i = 0;
	*lst = NULL;
	ft_putendl("test");
	while (av[i])
		*lst = add_arg_lst(*lst, av[i++]);
	return (*lst);
}
