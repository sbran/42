/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_select.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sbran <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/05/03 16:57:22 by sbran             #+#    #+#             */
/*   Updated: 2014/05/03 18:01:26 by sbran            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_SELECT_H
# define FT_SELECT_H

# include "./libft/includes/libft.h"

typedef struct			s_dlist
{
	char				*arg;
	int					select;
	int					cursor;
	struct s_dlist		*prev;
	struct s_dlist		*next;
}						t_dlist;

t_dlist					*init_lst(t_dlist **lst, char **av);
void					print_lst(t_dlist *start);
int						restore_shell(struct termios *term);

#endif
