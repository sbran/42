/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   init_draw.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sbran <sbran@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/19 15:22:56 by sbran             #+#    #+#             */
/*   Updated: 2014/01/19 15:23:02 by sbran            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "wolf3d.h"

void	init(t_env *env, int i)
{
	env->cameraX = 2 * i / (double)SCREEN_X - 1;
	env->rayPosX = env->posX;
	env->rayPosY = env->posY;
	env->rayDirX = env->dirX + env->planeX * env->cameraX;
	env->rayDirY = env->dirY + env->planeY * env->cameraX;
	env->mapX = (int)env->rayPosX;
	env->mapY = (int)env->rayPosY;
	env->deltaDistX = sqrt(1 + (env->rayDirY * env->rayDirY) / (env->rayDirX * env->rayDirX));
	env->deltaDistY = sqrt(1 + (env->rayDirX * env->rayDirX) / (env->rayDirY * env->rayDirY));
	env->hit = 0;
}

void	check_hit(t_env *env)
{
	while (!env->hit)
	{
		if (env->sideDistX < env->sideDistY)
		{
			env->sideDistX += env->deltaDistX;
			env->mapX += env->stepX;
			env->side = 0;
		}
		else
		{
			env->sideDistY += env->deltaDistY;
			env->mapY += env->stepY;
			env->side = 1;
		}
		if (env->tab[env->mapX][env->mapY] > 0)
			env->hit = 1;
	}
}

void	calc_ray(t_env *env)
{
	if (env->rayDirX < 0)
	{
		env->stepX = -1;
		env->sideDistX = (env->rayPosX - env->mapX) * env->deltaDistX;
	}
	else
	{
		env->stepX = 1;
		env->sideDistX = (env->mapX + 1.0 - env->rayPosX) * env->deltaDistX;
	}
	if (env->rayDirY < 0)
	{
		env->stepY = -1;
		env->sideDistY = (env->rayPosY - env->mapY) * env->deltaDistY;
	}
	else
	{
		env->stepY = 1;
		env->sideDistY = (env->mapY + 1.0 - env->rayPosY) * env->deltaDistY;
	}
}

void	calc_draw(t_env *env)
{
	if (!env->side)
		env->wallDist = fabs((env->mapX - env->rayPosX + (1 - env->stepX) / 2) / env->rayDirX);
	else
		env->wallDist = fabs((env->mapY - env->rayPosY + (1 - env->stepY) / 2) / env->rayDirY);
	env->lineH = abs((int)(SCREEN_Y / env->wallDist));
	env->drawStart = -(env->lineH) / 2 + SCREEN_Y / 2;
	env->drawEnd = env->lineH / 2 + SCREEN_Y / 2;
	if (env->drawStart < 0)
		env->drawStart = 0;
	if (env->drawEnd >= SCREEN_Y)
		env->drawEnd = SCREEN_Y - 1;
}
