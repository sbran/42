/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   movenv.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sbran <sbran@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/19 16:00:00 by sbran             #+#    #+#             */
/*   Updated: 2014/01/19 16:00:02 by sbran            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "wolf3d.h"

void	move_up(t_env *env)
{
	if (env->tab[(int)(env->posX + env->dirX)][(int)(env->posY)] == 0)
		env->posX += env->dirX;
	if (env->tab[(int)(env->posX)][(int)(env->posY + env->dirY)] == 0)
		env->posY += env->dirY;
}

void	move_down(t_env *env)
{
	if (env->tab[(int)(env->posX - env->dirX)][(int)(env->posY)] == 0)
		env->posX -= env->dirX;
	if (env->tab[(int)(env->posX)][(int)(env->posY - env->dirY)] == 0)
		env->posY -= env->dirY;
}

void	move_left(t_env *env)
{
	env->oldDirX = env->dirX;
	env->dirX = env->dirX * cos(-(0.5)) - env->dirY * sin(-(0.5));
	env->dirY = env->oldDirX * sin(-(0.5)) + env->dirY * cos(-(0.5));
	env->oldPlaneX = env->planeX;
	env->planeX = env->planeX * cos(-(0.5)) - env->planeY * sin(-(0.5));
	env->planeY = env->oldPlaneX * sin(-(0.5)) + env->planeY * cos(-(0.5));
}

void	move_right(t_env *env)
{
	env->oldDirX = env->dirX;
	env->dirX = env->dirX * cos((0.5)) - env->dirY * sin((0.5));
	env->dirY = env->oldDirX * sin((0.5)) + env->dirY * cos((0.5));
	env->oldPlaneX = env->planeX;
	env->planeX = env->planeX * cos((0.5)) - env->planeY * sin((0.5));
	env->planeY = env->oldPlaneX * sin((0.5)) + env->planeY * cos((0.5));
}
