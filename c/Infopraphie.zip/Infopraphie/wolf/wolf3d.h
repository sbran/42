/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   wolf3d.h                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sbran <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/07 15:02:25 by sbran             #+#    #+#             */
/*   Updated: 2014/01/14 20:50:54 by sbran            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef WOLF3D_H
# define WOLF3D_H

# define RGB_SKY 0x77B5FE /*bleu ciel*/
# define RGB_FLOOR 0xBBACAC /*gris*/
# define RGB_WALL_N 0x386F48 /*vert*/
# define RGB_WALL_E 0xFF00B8 /*rose violet*/
# define RGB_WALL_O 0xFF5B2B /*orange*/
# define RGB_WALL_S 0xFFF168 /*jaune poussin*/
# define SCREEN_X 800.0
# define SCREEN_Y 600.0
# define WALL 64.0
# define ANGCHVI 60.0

# include <mlx.h>
# include <stdlib.h>
# include <fcntl.h>
# include <math.h>
# include "libft/libft.h"

typedef struct      s_env
{
	int		argc;
	char	**argv;
	int		nbr_line;
	int		nbr_col;
	int		fd;
	char	*line;
	int		**tab;
	void	*mlx;
	void	*win;
	double  rayPosX;
    double  rayPosY;
    double  rayDirX;
    double  rayDirY;
    int     mapX;
    int     mapY;
    double  sideDistX;
    double  sideDistY;
    double  deltaDistX;
    double  deltaDistY;
    double  wallDist;
    int     stepX;
    int     stepY;
    int     hit;
    int     side;
    int     lineH;
    int     drawStart;
    int     drawEnd;
	double  cameraX;
    double  posX;
    double  posY;
    double  dirX;
    double  oldDirX;
    double  dirY;
    double  planeX;
    double  oldPlaneX;
    double  planeY;
    double  distX;
    double  distY;
}					t_env;

void    init(t_env *env, int i);
void    check_hit(t_env *env);
void    calc_ray(t_env *env);
void    calc_draw(t_env *env);
void    move_up(t_env *env);
void    move_down(t_env *env);
void    move_left(t_env *env);
void    move_right(t_env *env);
void    ft_stock_value(t_env *env);
void    ft_nbr_line_col(t_env *env);

#endif /* !WOLF3D_H */
