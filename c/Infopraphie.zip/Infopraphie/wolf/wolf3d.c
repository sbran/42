/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   wolf3d.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sbran <sbran@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/07 14:52:29 by sbran             #+#    #+#             */
/*   Updated: 2014/01/16 13:46:09 by sbran            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include "wolf3d.h"

void	draw(t_env *env)
{
	int		i;
	int		j;

	i = 0;
	while (i < SCREEN_X)
	{
		j = 0;
		init(env, i);
		calc_ray(env);
		check_hit(env);
		calc_draw(env);
		while (j < env->drawStart)
			mlx_pixel_put(env->mlx, env->win, i, j++, RGB_SKY);
		while (env->drawStart < env->drawEnd)
		{
				mlx_pixel_put(env->mlx, env->win, i, env->drawStart, RGB_WALL_O);
			env->drawStart++;
			j++;
		}
		while (j < SCREEN_Y)
			mlx_pixel_put(env->mlx, env->win, i, j++, RGB_FLOOR);
		i++;
	}
}

int     expose_hook(t_env *env)
{
    draw(env);
    return (0);
}

int     key_hook(int keycode, t_env *env)
{
    if (keycode == 65307)
        exit(1);
	if (keycode == 119)
		move_up(env);
	if (keycode == 115)
	    move_down(env);
	if (keycode == 97)
		move_left(env);
	if (keycode == 100)
		move_right(env);
	/*mlx_clear_window(env->mlx, env->win);*/
	draw(env);
    return (0);
}

int		main(int argc, char **argv)
{
	t_env		env;

	env.argc = argc;
    env.argv = argv;
	ft_nbr_line_col(&env);
    ft_stock_value(&env);
    env.posX = 2;
    env.posY = 2;
    env.dirX = 1;
    env.dirY = 0;
    env.planeX = 0;
    env.planeY = 0.66;
    env.mlx = mlx_init();
    env.win = mlx_new_window(env.mlx, SCREEN_X, SCREEN_Y, "wolf3d");
    mlx_expose_hook(env.win, expose_hook, &env);
    mlx_key_hook(env.win, key_hook, &env);
    mlx_loop(env.mlx);
	return (0);
}
