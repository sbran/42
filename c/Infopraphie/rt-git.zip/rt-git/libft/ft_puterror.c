#include "libft.h"

void	ft_puterror(char *str)
{
  write(2, str, ft_strlen(str));
  exit(EXIT_FAILURE);
}