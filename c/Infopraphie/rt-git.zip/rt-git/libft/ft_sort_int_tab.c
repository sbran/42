#include "libft.h"
#include <unistd.h>

void	ft_sort_int_tab(int *tab, unsigned int size)
{
  size_t  i;
  size_t  j;
  int     tmp;

  i = -1;
  while (i < size)
  {
    j = size - 1;
    while (j > i)
    {
      if (tab[i] > tab[j])
      {
        tmp = tab[i];
        tab[i] = tab[j];
        tab[j] = tmp;
        j = size - 1;
      }
      else
        j--;
    }
  }
}
