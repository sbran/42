/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   interpolation2d.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: atouzeau <atouzeau@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/06/08 16:55:20 by atouzeau          #+#    #+#             */
/*   Updated: 2014/06/19 18:13:38 by sbran            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <math.h>
#include <time.h>
#include "rt.h"

double			interpolation_cos(double a, double b, double x)
{
	double		k;

	k = (1 - cos(x * M_PI)) / 2;
	return ((a * (1 - k) + b * k));
}

double			interpolation_cos2d(t_perlin perlin, double x, double y)
{
	double		x1;
	double		x2;

	x1 = interpolation_cos(perlin.a, perlin.b, x);
	x2 = interpolation_cos(perlin.c, perlin.d, x);
	return (interpolation_cos(x1, x2, y));
}

double			fonction_bruit2d(double x, double y, double *valeurs2d)
{
	int			i;
	int			j;
	double		pas;
	t_perlin	perlin;

	pas = PAS;
	i = (int)(x / PAS);
	j = (int)(y / PAS);
	perlin.a = bruit2d(i, j, valeurs2d);
	perlin.b = bruit2d(i + 1, j, valeurs2d);
	perlin.c = bruit2d(i, j + 1, valeurs2d);
	perlin.d = bruit2d(i + 1, j + 1, valeurs2d);
	return (interpolation_cos2d(perlin, fmod((x / pas), 1),
		fmod((y / pas), 1)));
}

double			bruit_coherent2d(double x, double y, double *valeurs2d)
{
	int			i;
	int			f;
	double		p;
	double		somme;
	double		persistance;

	i = 0;
	f = 1;
	p = 1;
	somme = 0.0;
	persistance = 0.5;
	while (i < OCTAVES)
	{
		somme += p * fonction_bruit2d(x * f, y * f, valeurs2d);
		p *= persistance;
		f *= 2;
		i++;
	}
	return ((somme * (1 - persistance) / (1 - p)));
}

void			ft_perlin(double bruit, int mark, t_objet *tmp, double x)
{
	double			va;

	if (mark == 1)
		va = 1 - sqrt(fabs(sin(2 * 3.141592 * bruit)));
	if (mark == 2)
		va = (1 - cos(LIGNES * 2 * M_PI * (x / WIN_Y + PERT * bruit))) / 2;
	if (mark == 3)
		va = bruit;
	tmp->color.red = tmp->pm_color.red * (1 - va) + tmp->ps_color.red * va;
	tmp->color.blue = tmp->pm_color.blue * (1 - va) + tmp->ps_color.blue * va;
	tmp->color.green = tmp->pm_color.green *
		(1 - va) + tmp->ps_color.green * va;
}
