/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rand_bruit.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: atouzeau <atouzeau@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/06/08 11:24:51 by atouzeau          #+#    #+#             */
/*   Updated: 2014/06/19 18:40:05 by sbran            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include	<stdlib.h>
#include	<stdio.h>
#include	<time.h>
#include	<math.h>
#include	<sys/types.h>
#include	<unistd.h>
#include	<string.h>
#include	"rt.h"

static int		g_longueur_max = 0;
static int		g_hauteur_max;

double			*init_bruit2d(int l, int h, int p, int n)
{
	int			i;
	double		*valeurs2d;

	i = 0;
	g_longueur_max = (int)(ceil(l * pow(2, n - 1) / p));
	g_hauteur_max = (int)ceil(h * pow(2, n - 1) / p);
	valeurs2d = malloc(sizeof(double) * (g_longueur_max * g_hauteur_max + 1));
	srand(time(NULL) * getpid());
	while (i < g_longueur_max * g_hauteur_max)
	{
		valeurs2d[i] = ((double)rand()) / RAND_MAX;
		i++;
	}
	return (valeurs2d);
}

double			bruit2d(int i, int j, double *valeurs2d)
{
	double			test;

	test = 0.0;
	if ((i * g_longueur_max + j) < (g_longueur_max * g_hauteur_max))
		test = valeurs2d[i * g_longueur_max + j];
	return (test);
}
