/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: atouzeau <atouzeau@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/06/08 06:29:24 by atouzeau          #+#    #+#             */
/*   Updated: 2014/06/19 18:05:49 by sbran            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <mlx.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include "rt.h"

void	treat_image(t_param *param, char *file)
{
	int		ret;

	ret = get_scene(param, file);
	if (ret == -1)
		exit(0);
	rempli_img(param);
}

void	init_libx(t_param *param, char *file)
{
	param->mlx_ptr = mlx_init();
	if (param->mlx_ptr == 0)
		ft_puterror("Can't init libx.\n");
	param->win_ptr = mlx_new_window(param->mlx_ptr, WIN_X, WIN_Y, "Raytracer");
	param->img = mlx_new_image(param->mlx_ptr, WIN_X, WIN_Y);
	treat_image(param, file);
	mlx_key_hook(param->win_ptr, &key, &param);
	mlx_expose_hook(param->win_ptr, &expose, param);
	mlx_loop(param->mlx_ptr);
}

int		main(int argc, char **argv)
{
	t_param		param;

	if (argc == 2)
		init_libx(&param, argv[1]);
	else if (argc == 1)
		ft_putstr("Please select a configuration file.\n");
	else
		ft_putstr("Select just one configuration file.\n");
	return (0);
}
