/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   perlin.h                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: atouzeau <atouzeau@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/06/08 11:17:54 by atouzeau          #+#    #+#             */
/*   Updated: 2014/06/19 17:54:03 by sbran            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef	PERLIN_H
# define PERLIN_H

# define PERT 			0.25
# define PAS			128
# define LIGNES			30
# define OCTAVES		8
# define PERSISTANCE	0.01

double		bruit2d(int i, int j, double *valeur2d);
double		*init_bruit2d(int l, int h, int p, int n);
double		bruit_coherent2d(double x, double y, double *valeur2d);
void		ft_perlin(double bruit, int mark, t_objet *tmp, double x);

#endif
